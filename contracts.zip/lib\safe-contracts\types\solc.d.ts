declare module "solc";
